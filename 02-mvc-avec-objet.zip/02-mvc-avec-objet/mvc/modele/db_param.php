<?php

/**
*  Param�tres de connexion au serveur MYSQL
*  Inclus dans : model/connect.php
*/

const DB_USERNAME = 'root'; //nom d'utilisateur
const DB_PASSWORD = ''; //mot de passe
const DB_DATABASE = 'mvctest'; //nom de la base de donn�es � s�l�ctionner

// Rien � modifier ici noramlement
const DB_HOST = 'localhost';
const DB_PORT = '3306';