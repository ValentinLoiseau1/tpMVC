<?php

/**
*  Param�tres de la table USER
*  Inclus dans tous les fichiers du dossier : controler/user
*/

define('DB_USER_TABLE', 'clients_tbl'); // nom de la table d'utilisateur

